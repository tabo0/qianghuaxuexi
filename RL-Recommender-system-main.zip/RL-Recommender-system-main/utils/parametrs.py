class CFG:
    learning_rate = 0.1
    path_to_csv = "articles.csv"
    device = 'cpu'
    gamma = 0.5
    total_no_of_pred = 10
    no_embedding = 30